create database capstone;
use capstone;

select * from capstone;

# Highest sales ?
select max(sales) highest_sales from capstone;

# Top 5 products based on sales ?
select product,sales from capstone order by 
sales desc limit 5 ;